# 胡子幼 · 影像作品集（第三版）

## 本地预览
直接打开 `index.html`（保持 `assets` 文件夹在同一目录）即可查看。

## 发布到 GitHub Pages（当前尚未发布）
将 `index.html` 与 `assets/` 文件夹一同上传到 GitHub 仓库，随后在仓库 Settings → Pages 中选择 Deploy from a branch / main / root。

## 页面内容
最新确认的中文个人介绍；英文为对应翻译。摄影及影像画面来自原本科作品集 PDF 的整理素材。影片暂无可播放视频文件，点击作品可以浏览原作品集页。联系方式暂仅放 GitHub，不编造邮箱。

当前版本：深海蓝—青绿—暖橘渐变、等高线视觉、响应式布局。
